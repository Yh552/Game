﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GameYH
{
    public class Player
    {
        public string Charname;
        public String _charname;
        public string race;
        public string clss;
        public int health;
        public int attack;
        public string skills;
        public void warriorClass()
        {
            health = 13;
            attack = 9;
            skills = "Warrior uses Greatsword.\nYour health is 13 and your attack power is 9";
        }

        public void archerClass()
        {
            health = 10;
            attack = 12;
            skills = "Archer uses a Bow\nYour health is 10 and your attack power is 12";
        }
        public void wizardClass()
        {
            health = 8;
            attack = 13;
            skills = "Wizard uses a Staff\nYour health is 8 and your attack power is 13";
        }
        public void fireBall(Monster enemy)
        {
            enemy.health -= 4;
            MessageBox.Show("You used fireBall ability, the enemy hp  is " + enemy.health + "\n" + enemy.monsterUsedSkill(enemy.monsterPicks()) + " \n Your hp is " + health);
        }

        public void blazeBolt(Monster enemy)
        {
            enemy.health -= 3;
            MessageBox.Show("You used blazeBolt ability, the enemy hp  is " + enemy.health + "\n" + enemy.monsterUsedSkill(enemy.monsterPicks()) + " \n Your hp is " + health);
        }

        public void doubleSlash(Monster enemy)
        {
            enemy.health -= 2;
            MessageBox.Show("You used doubleSlash ability, the enemy hp  is " + enemy.health + "\n" + enemy.monsterUsedSkill(enemy.monsterPicks()) + " \n Your hp is " + health);
        }
        public void autoAttack(Monster enemy)
        {
            enemy.health -= 1;
            MessageBox.Show("You have attacked, the enemy hp  is " + enemy.health+"\n" + enemy.monsterUsedSkill(enemy.monsterPicks()) + " \n Your hp is " + health);

        }

        public void heal()
        {
            Console.WriteLine("You healed for 5 hp");

            if (health > 15)
            {
                Console.WriteLine("Your health is full, you cannot have more than 15 healthpoint");
                health = 15;
            }
            else
            {
                health += 5;
            }

        }
        public int actionMenu(int num)
        {
            return num;
        }
        public void attackType(int decision, Monster enemy, string classes)
        {
            if (decision == 1)
            {
                autoAttack(enemy);

            }
            else if (decision == 2)
            {
                heal();

            }
            else if (decision == 3)
            {


                switch (classes.ToLower())
                {
                    case "wizard":
                        fireBall(enemy);

                        break;
                    case "warrior":
                        doubleSlash(enemy);


                        break;
                    default:
                        blazeBolt(enemy);

                        break;
                }
            }
        }

    }

}

