﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GameYH
{
    /// <summary>
    /// Interaction logic for RaceMenu.xaml
    /// </summary>
    public partial class RaceMenu : Page
    {
        Player Player = new Player();
        public RaceMenu()
        {
            InitializeComponent();
        }

        private void HumanButton(object sender, RoutedEventArgs e)
        {



            if (string.IsNullOrEmpty(UserName.Text))
            {
                MessageBox.Show("User name cannot be empty");

            }
            else
            {
                Player.race = "Human";
                
                Player.Charname = UserName.Text;
                NavigationService.Navigate(new ClassMenu(Player));
            }
        }



            private void DwarfButton(object sender, RoutedEventArgs e)
            {


                if (string.IsNullOrEmpty(UserName.Text))
                {
                    MessageBox.Show("User name cannot be empty");
                }
                else
                {
                    Player.race = "Dwarf";
                    
                    Player.Charname = UserName.Text;
                NavigationService.Navigate(new ClassMenu(Player));
            } }
            private void ElfButton(object sender, RoutedEventArgs e)
        {
           
            if (string.IsNullOrEmpty(UserName.Text))
            {
                MessageBox.Show("User name cannot be empty");
            }
            else
            {
                Player.race = "Elf";
                
                Player.Charname = UserName.Text;
                NavigationService.Navigate(new ClassMenu(Player));
            }

            
        }
    }
}
