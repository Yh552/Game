﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameYH
{
    public class Monster
    {
        public int monsterAttacks, attack, health;
        public string name;

        public Monster(String _name, int _attack, int _health)
        {
            name = _name;
            attack = _attack;
            health = _health;
        }
        public int monsterPicks()
        {

            int mPick;
            Random rand = new Random();
            mPick = rand.Next(1, monsterAttacks + 1);
            return mPick;
        }

        public virtual void monsterRoll(int roll, Player player)
        {
            Console.WriteLine("Monster turn to attack");
        }
        public virtual string monsterUsedSkill(int roll)
        {
            return "";
        }

    }
    public class Goblin : Monster
    {
        public Goblin(string _name, int _attack, int _health)
            : base(_name, _attack, _health)
        {
            monsterAttacks = 2;

        }
        public void goblinMace(Player player)
        {
            player.health -= 2;
            Console.WriteLine("The Goblin used the goblinMace on you, your remaining health is " + player.health);

        }

        public void goblinBite(Player player)
        {
            player.health -= 2;
            Console.WriteLine("The Goblin used the goblinBite on you, your remaining health is " + player.health);
        }

        public override void monsterRoll(int roll, Player player)
        {
            if (roll == 1)
            {
                goblinMace(player);


            }

            else if (roll == 2)
            {
                goblinBite(player);

            }
        }
        public override string monsterUsedSkill(int roll)
        {
            string[] ability = {"", "The Goblin used the goblinBite on you, the goblin hit you by ", "The Goblin used the goblinMace on you, the goblin hit you by " };
            if (roll == 1)
            {
                return ability[1]
                + attack;

            }

            else if (roll == 2)
            {
                return ability[2] + attack;
            }
            return ability[0];
        }
    }
    public class Orc : Monster
    {
        public Orc(string _name, int _attack, int _health)
            : base(_name, _attack, _health)
        {
            monsterAttacks = 2;

        }
        public void beastHandling(Player player)

        {
            player.health -= 3;
            Console.WriteLine("The Orc used beastHandling on you, your remaining health is " + player.health);

        }

        public void noseBleed(Player player)
        {
            player.health -= 3;
            Console.WriteLine("The Orc used noseBleed on you, your remaining health is " + player.health);

        }

        public override void monsterRoll(int roll, Player player)
        {
            if (roll == 1)
            {
                beastHandling(player);


            }

            else if (roll == 2)
            {
                noseBleed(player);

            }
        }
    }
    public class Dragon : Monster
    {
        public Dragon(string _name, int _attack, int _health)
            : base(_name, _attack, _health)
        {
            monsterAttacks = 2;

        }
        public void fireBreath(Player player)

        {
            player.health -= 5;
            Console.WriteLine("The Dragon used fireBreath on you, your remaining health is " + player.health);

        }

        public void tailCrush(Player player)
        {
            player.health -= 4;
            Console.WriteLine("The Dragon used tailCrush on you, your remaining health is " + player.health);

        }

        public override void monsterRoll(int roll, Player player)
        {
            if (roll == 1)
            {
                fireBreath(player);


            }

            else if (roll == 2)
            {
                tailCrush(player);

            }
        }
    }
}
