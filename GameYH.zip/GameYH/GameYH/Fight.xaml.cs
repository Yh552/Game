﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace GameYH
{
    /// <summary>
    /// Interaction logic for Fight.xaml
    /// </summary>
    public partial class Fight : INotifyPropertyChanged
    {
        Goblin goblin = new Goblin("Goblin", 2, 7);
        private Player Player;
        public Fight(Player player)
        {
            DataContext = this;
            InitializeComponent();
            
            Player = player;
            LoadPlayer();

        }
        private void LoadPlayer()
        {
            username.Text = Player.Charname;
            PlayerAge.Text = Player.race;
            PlayerClass.Text = Player.clss;

        }



        private void AttackClick(object sender, RoutedEventArgs e)
        {
            
            while (goblin.health > 0 && Player.health > 0)
            {

                
                if (goblin.health > 0)
                {
                    goblin.monsterRoll(goblin.monsterPicks(), Player);
                    if (Player.health <= 0)
                    {
                        MessageBox.Show("You Died");
                        break;
                    }
                }
                
                Player.attackType(Player.actionMenu(1), goblin, Player.clss);
                return;
            }
            
            if (goblin.health <= 0)
            {
                MessageBox.Show("goblin is dead");
            }
            OnPropertyChanged();
        }
       

        private void HealthClick(object sender, RoutedEventArgs e)
        {
            if (Player.health >= 15)

            {
                MessageBox.Show("Hp cannot be higer than 15");
                Player.health = 15;
            }
            else
            {
                Player.health += 5;
                MessageBox.Show("You healed by 5 points. Your health point is "+ Player.health);
            }

        }

        private void SpecialClick(object sender, RoutedEventArgs e)
        {
            
            while (goblin.health > 0 && Player.health > 0)
            {


                if (goblin.health > 0)
                {
                    goblin.monsterRoll(goblin.monsterPicks(), Player);
                    if (Player.health <= 0)
                    {
                        MessageBox.Show("You Died");
                        break;
                    }
                }
                
                Player.attackType(Player.actionMenu(3), goblin, Player.clss);
                return;
            }

            if (goblin.health <= 0)
            {
                MessageBox.Show("Goblin is dead");
            }
            OnPropertyChanged();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }

}
