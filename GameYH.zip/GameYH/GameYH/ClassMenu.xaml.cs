﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GameYH
{
    /// <summary>
    /// Interaction logic for ClassMenu.xaml
    /// </summary>
    public partial class ClassMenu : Page
    {
        private Player Player;
        public ClassMenu(Player player)
        {
            InitializeComponent();


            Player = player;
            LoadPlayer();
        }

        private void LoadPlayer()
        {
            PlayerAge.Text = Player.race;
            UserName.Text = Player.Charname;
        }


        private void WarriorClick(object sender, RoutedEventArgs e)
        {
            Player.clss = "Warrior";
            Player.warriorClass();
            
            NavigationService.Navigate(new Fight(Player));
        }


        private void ArcherClick(object sender, RoutedEventArgs e)
        {
            Player.clss = "Archer";
            Player.archerClass();
            
            NavigationService.Navigate(new Fight(Player));
        }

        private void WizardClick(object sender, RoutedEventArgs e)
        {
            Player.clss = "Wizard";
            Player.wizardClass();
            
            NavigationService.Navigate(new Fight(Player));
        }

        
    }
}
